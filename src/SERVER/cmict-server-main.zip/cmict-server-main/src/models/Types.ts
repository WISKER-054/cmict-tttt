import { MediaTypes } from '~/constants/enums'

export type Media = {
    url: string
    type: MediaTypes
}
