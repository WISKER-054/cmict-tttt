import logo from './logo.png'
import avatar from './avatar.png'
import slide1 from './slide-1.png'
import slide2 from './slide-2.png'
import slide3 from './slide-3.png'
import slide4 from './slide-4.png'
import slide5 from './slide-5.png'

const images = {
    logo,
    avatar,
    slide1,
    slide2,
    slide3,
    slide4,
    slide5
}

export default images
