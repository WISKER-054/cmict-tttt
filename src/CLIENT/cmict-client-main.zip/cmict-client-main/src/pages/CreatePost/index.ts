export { default } from './CreatePost'
