export { default } from './PostDetail'
