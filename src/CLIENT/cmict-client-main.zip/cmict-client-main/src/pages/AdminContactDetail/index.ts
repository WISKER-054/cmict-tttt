export { default } from './AdminContactDetail'
