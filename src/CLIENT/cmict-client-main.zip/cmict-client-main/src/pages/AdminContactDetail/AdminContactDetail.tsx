function AdminContactDetail() {
    return <div>AdminContactDetail</div>
}

export default AdminContactDetail
