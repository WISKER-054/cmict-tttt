export { default } from './EditPost'
