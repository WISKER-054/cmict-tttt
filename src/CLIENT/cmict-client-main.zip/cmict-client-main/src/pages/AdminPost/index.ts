export { default } from './AdminPost'
