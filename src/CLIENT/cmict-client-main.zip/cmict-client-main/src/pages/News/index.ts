export { default } from './News'
