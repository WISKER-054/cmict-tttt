export { default } from './MyPosts'
