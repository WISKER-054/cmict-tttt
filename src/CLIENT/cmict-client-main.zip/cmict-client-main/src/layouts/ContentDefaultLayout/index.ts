export { default } from './ContentDefaultLayout'
