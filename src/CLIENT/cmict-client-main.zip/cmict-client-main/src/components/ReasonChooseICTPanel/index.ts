export { default } from './ReasonChooseICTPanel'
