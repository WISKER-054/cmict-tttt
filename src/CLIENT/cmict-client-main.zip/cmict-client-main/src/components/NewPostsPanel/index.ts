export { default } from './NewPostsPanel'
