declare module 'markdown-it-ins' {
    export default function markdownItIns(md: any): void
}
