export type { Route } from './routes'

export { default } from './routes'
